import React from "react";
import { ProfileListItem } from "../../ProfileListItem/ProfileListItem";

const MatchesPage = () => {
  return (
    <div>
      <ProfileListItem />
    </div>
  );
};

export default MatchesPage;
