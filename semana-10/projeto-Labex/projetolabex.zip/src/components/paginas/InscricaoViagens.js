import React from "react";

const App = () => {
  return <div>Inscrição em viagens</div>;
};

export default App;
