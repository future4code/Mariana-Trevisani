import React from "react";
import styled from "styled-components";

const Teste = styled.div`
  background-color: yellow;
`;

const App = () => {
  return (
    <div>
      <Teste>HOME</Teste>
    </div>
  );
};

export default App;
