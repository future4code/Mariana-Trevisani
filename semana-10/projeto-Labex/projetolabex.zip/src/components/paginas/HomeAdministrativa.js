import React from "react";

const App = () => {
  return <div>Home área administrativa</div>;
};

export default App;
