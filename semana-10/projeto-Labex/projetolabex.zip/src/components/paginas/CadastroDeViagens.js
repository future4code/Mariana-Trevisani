import React from "react";

const App = () => {
  return <div>Cadastro de viagens</div>;
};

export default App;
